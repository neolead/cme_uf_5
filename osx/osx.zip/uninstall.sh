#!/bin/bash
# CME UF MIDI Keyboard Uninstaller for macOS

echo "Removing CME UF MIDI driver..."

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: Run with sudo"
    exit 1
fi

KEXT="/Library/Extensions/CME_UF_MIDI.kext"

if [ -d "$KEXT" ]; then
    kextunload "$KEXT" 2>/dev/null
    rm -rf "$KEXT"
    touch /Library/Extensions
    kextcache -invalidate / 2>/dev/null || true
    echo "Driver removed. Please reconnect keyboard."
else
    echo "Driver not found at $KEXT"
fi
