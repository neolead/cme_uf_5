#!/bin/bash
# CME UF MIDI Keyboard Driver Installer for macOS
# Supports: CME UF5, UF6, UF7, UF8, UF50, UF60, UF70
# USB VID: 0x7104 (28932) / PID: 0x2202 (8706)

echo "============================================"
echo " CME UF MIDI Keyboard Driver Installer"
echo " macOS"
echo "============================================"
echo ""

# Check for root
if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: This script must be run with sudo!"
    echo "Usage: sudo ./install.sh"
    exit 1
fi

KEXT_DIR="/Library/Extensions"
KEXT_NAME="CME_UF_MIDI.kext"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "Installing $KEXT_NAME to $KEXT_DIR..."

# Remove old version if exists
if [ -d "$KEXT_DIR/$KEXT_NAME" ]; then
    echo "Removing old version..."
    rm -rf "$KEXT_DIR/$KEXT_NAME"
fi

# Copy kext
cp -R "$SCRIPT_DIR/$KEXT_NAME" "$KEXT_DIR/"

# Set permissions
chown -R root:wheel "$KEXT_DIR/$KEXT_NAME"
chmod -R 755 "$KEXT_DIR/$KEXT_NAME"

# Touch extensions dir to invalidate kext cache
touch "$KEXT_DIR"

# Rebuild kext cache
echo "Rebuilding kext cache..."
kextcache -invalidate / 2>/dev/null || true
kmutil install --volume-root / 2>/dev/null || true

echo ""
echo "============================================"
echo " Installation complete!"
echo ""
echo " Please reconnect your CME UF keyboard."
echo " If this is the first install, you may need"
echo " to approve the extension in:"
echo "   System Settings > Privacy & Security"
echo " and then reboot."
echo "============================================"
