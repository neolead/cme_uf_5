# CME UF MIDI Keyboard Driver - macOS

## Supported Devices
- CME UF5, UF6, UF7, UF8, UF50, UF60, UF70
- USB VID: 0x7104 (28932) / PID: 0x2202 (8706)

## How It Works
This is a codeless kext — it contains no binary code, only a property list
that tells macOS to use Apple's built-in USB MIDI driver (AppleUSBMIDIDriver)
for your CME UF keyboard.

## Files
- CME_UF_MIDI.kext/ - Codeless kernel extension
- install.sh - Installer (run with sudo)
- uninstall.sh - Uninstaller (run with sudo)

## Installation
```bash
sudo ./install.sh
```

## Manual Installation
```bash
sudo cp -R CME_UF_MIDI.kext /Library/Extensions/
sudo chown -R root:wheel /Library/Extensions/CME_UF_MIDI.kext
sudo chmod -R 755 /Library/Extensions/CME_UF_MIDI.kext
sudo touch /Library/Extensions
sudo kextcache -invalidate /
```

## Post-Installation
1. Reconnect your CME UF keyboard
2. Open Audio MIDI Setup (in /Applications/Utilities/)
3. You should see CME UF MIDI in the MIDI devices list
4. If prompted, approve the extension in System Settings > Privacy & Security

## macOS Compatibility
- macOS 10.9 - 12 (Monterey): Works directly
- macOS 13+ (Ventura/Sonoma/Sequoia): May need kext approval in Privacy & Security
- Note: Many CME keyboards are USB MIDI class-compliant and may work without this driver. Try connecting first!

## Uninstallation
```bash
sudo ./uninstall.sh
```

## Troubleshooting
- If not detected: Check System Information > USB for VID 0x7104 PID 0x2202
- If no MIDI in Audio MIDI Setup: Reboot after install
- If kext won't load on macOS 13+: Approve in Security settings
